#include <bits/stdc++.h>
#include "user.h"
#include "course.h"
using namespace std;
struct Nodestudent{
    Student data;
    Nodestudent* next;
};
struct Nodecourse{
    course data;
    Nodecourse* next;
};
struct Nodeuser{
    user data;
    Nodeuser* next;
};
struct Linkedliststudent{
    Nodestudent* head = NULL;
    Nodestudent* tail = NULL;
};
struct Linkedlistcourse{
    Nodecourse* head = NULL;
    Nodecourse* tail = NULL;
};
void Insert(Linkedlistcourse &lst, course data);


