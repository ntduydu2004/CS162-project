#include <bits/stdc++.h>
using namespace std;

struct Date{
    int dd, mm, yy;
};
struct Time{
    int min, hour;
};